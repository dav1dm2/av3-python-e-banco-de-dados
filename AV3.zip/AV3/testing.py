#testing.py
from db import executar_query
from utils import Obrigar_input, verificar_senha, gerar_hash_senha


'''senha = "admin123"
hash_senha = gerar_hash_senha(senha).decode('utf-8')  # Decodificar para salvar como string no banco
print(f"Hash gerado: {hash_senha}")
'''


senha = "1234"
hash_armazenado = gerar_hash_senha(senha)
print(f"Senha original: {senha}")
print(f"Hash gerado: {hash_armazenado}")


senha_tentativa = "1234"
resultado = verificar_senha(senha_tentativa, hash_armazenado)
print(f"Login com senha '{senha_tentativa}': {'Sucesso' if resultado else 'Falha'}")


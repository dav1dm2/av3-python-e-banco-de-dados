from db import executar_query
from utils import Obrigar_input, verificar_senha, gerar_hash_senha

def menu_entregadores():
    while True:
        print("\n=== Menu de Entregadores ===")
        print("1. Cadastrar")
        print("2. Logar")
        print("0. Voltar")
        opcao = input("Escolha uma opção: ")

        if opcao == "1":
            cadastrar_entregador()
        elif opcao == "2":
            logar_entregador()
        elif opcao == "0":
            break
        else:
            print("Opção inválida. Tente novamente.")

def cadastrar_entregador():
    print("\n=== Cadastro de Entregador ===")
    nome = Obrigar_input("Nome: ")
    cpf = Obrigar_input("CPF: ")
    telefone = Obrigar_input("Telefone: ")

    usa_veiculo = input("\nVocê utiliza veículos emplacados para entregas? (s/n): ").strip().lower()
    if usa_veiculo == "s":
        cnh = Obrigar_input("CNH: ")
        modelo_veiculo = Obrigar_input("Modelo do Veículo: ")
        placa_veiculo = Obrigar_input("Placa do Veículo: ")
    else:
        cnh = None
        modelo_veiculo = None
        placa_veiculo = None

    senha = Obrigar_input("Senha: ")
    hash_senha = gerar_hash_senha(senha)

    query = """
        INSERT INTO Entregadores (Nome, CPF, Telefone, CNH, ModeloVeiculo, PlacaVeiculo, Senha)
        VALUES (%s, %s, %s, %s, %s, %s, %s)
    """
    try:
        executar_query(query, (nome, cpf, telefone, cnh, modelo_veiculo, placa_veiculo, hash_senha))
        print("Entregador cadastrado com sucesso!")
    except Exception as e:
        print(f"Erro ao cadastrar entregador: {e}")

def logar_entregador():
    print("\n=== Login de Entregador ===")
    cpf = input("CPF: ")
    senha = input("Senha: ")

    query = "SELECT * FROM Entregadores WHERE CPF = %s"
    entregador = executar_query(query, (cpf,)) 

    if entregador and verificar_senha(senha, entregador[0]['senha']):
        print(f"Bem-vindo(a), {entregador[0]['Nome']}!")
        
    else:
        print("CPF ou senha inválidos. Tente novamente.")

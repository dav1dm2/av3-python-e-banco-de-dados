from db import executar_query
from utils import Obrigar_input, verificar_senha, gerar_hash_senha

def menu_empregados():
    while True:
        print("\n=== Menu de Empregados ===")
        print("1. Logar")
        print("0. Voltar")
        opcao = input("Escolha uma opção: ")

        if opcao == "1":
            logar_empregado()
        elif opcao == "0":
            break
        else:
            print("Opção inválida. Tente novamente.")

def logar_empregado():
    print("\n=== Login de Empregado ===")
    cpf = input("CPF: ")
    senha = input("Senha: ")

    query = "SELECT * FROM Empregados WHERE CPF = %s"
    empregado = executar_query(query, (cpf,))

    if empregado and len(empregado) > 0 and verificar_senha(senha, empregado[0]['senha']):
        print(f"Bem-vindo(a), {empregado[0]['nome']}!")
        if empregado[0]['cargo'] == 'Administrador':
            menu_admin()
        else:
            print("Você não possui permissões administrativas.")
    else:
        print("CPF ou senha inválidos. Tente novamente.")

def menu_admin():
    while True:
        print("\n=== Menu do Administrador ===")
        print("1. Cadastrar novo empregado")
        print("0. Sair")
        opcao = input("Escolha uma opção: ")

        if opcao == "1":
            cadastrar_empregado()
        elif opcao == "0":
            break
        else:
            print("Opção inválida. Tente novamente.")

def cadastrar_empregado():
    print("\n=== Cadastro de Novo Empregado ===")
    nome = Obrigar_input("Nome: ")
    cpf = Obrigar_input("CPF: ")
    cargo = Obrigar_input("Cargo: ")
    salario = float(Obrigar_input("Salário: "))
    data_admissao = Obrigar_input("Data de Admissão (AAAA-MM-DD): ")
    senha = Obrigar_input("Senha: ")
    hash_senha = gerar_hash_senha(senha)

    query = """
        INSERT INTO Empregados (Nome, CPF, Cargo, Salario, DataAdmissao, Senha)
        VALUES (%s, %s, %s, %s, %s, %s)
    """
    try:
        executar_query(query, (nome, cpf, cargo, salario, data_admissao, hash_senha))
        print("Novo empregado cadastrado com sucesso!")
    except Exception as e:
        print(f"Erro ao cadastrar empregado: {e}")

